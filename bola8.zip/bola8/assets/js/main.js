//---------------------creando procedimiento para saludar a user-------------//
let userName ="";
userName=prompt("introduce tu nombre: ");
console.log(userName);
userName ==="" ? console.log("Hola!"):console.log(`Hola, ${userName}!`);
//-------------------aqui recibiremos prgunta del user ------------------//
let userQuestion="";
userQuestion= prompt("cuál es tu pregunta?: ");
console.log(`Entonces la pregunta de ${userName}e es: ${userQuestion} ??`);
//----------------aqui creare el proceso para responder--------------------//
let randomNumber=0;
randomNumber=Math.floor(Math.random()*8);
console.log(randomNumber);
let eigthBall='';
eigthBall= randomNumber;
switch (eigthBall){
    case 1:console.log('It is certain');
    break;
    case 2:console.log('It is decidedly so');
    break;
    case 3:console.log('Reply hazy try again');
    break;
    case 4:console.log('Cannot predict now');
    break;
    case 5:console.log('Do not count on it');
    break;
    case 6:console.log('My sources say no');
    break;
    case 7:console.log('Outlook not so good');
    break;
    case 8:console.log('Signs point to yes');
    break;
    default:console.log("don't know") 

}

